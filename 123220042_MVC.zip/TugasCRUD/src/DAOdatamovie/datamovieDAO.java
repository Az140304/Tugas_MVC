/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOdatamovie;
import java.sql.*;
import java.util.*;
import konektor.connector;
import model.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import DAOImplement.datamovieimplement;
/**
 *
 * @author DELL
 */
public class datamovieDAO implements datamovieimplement  {
    Connection connection;
    
    final String select = "SELECT * FROM film";
    final String insert = "INSERT INTO film (judul, alur, penokohan, akting, rating) VALUES (?, ?, ?, ?, ?);";
    final String update = "UPDATE film set judul=?,  alur=?, penokohan=?, akting=?, rating=? where judul=?;";
    final String delete = "DELETE FROM film where judul=?";
    final String deleteAll = "DELETE FROM film";
    
    public datamovieDAO(){
        connection = connector.connection();
    }

    @Override
    public void insert(datamovie p) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, p.getJudul());
            statement.setInt(2, p.getAlur());
            statement.setInt(3, p.getPenokohan());
            statement.setInt(4, p.getAkting());
            statement.setInt(5, p.getRating());
            statement.executeUpdate();
            
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            } catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void update(datamovie p) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(update);
            statement.setString(1, p.getJudul());
            statement.setInt(2, p.getAlur());
            statement.setInt(3, p.getPenokohan());
            statement.setInt(4, p.getAkting());
            statement.setInt(5, p.getRating());
            statement.setString(6, p.getJudul());
            statement.executeUpdate();

            
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
                
            } catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }
    
    @Override
    public void delete(String judul) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(delete);
            statement.setString(1, judul);

            statement.executeUpdate();
                   
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            } catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<datamovie> getAll() {
        List<datamovie> dp = null;
        try {
            dp = new ArrayList<datamovie>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while(rs.next()){
                datamovie hp = new datamovie();
                hp.setJudul(rs.getString("judul"));
                hp.setAlur(rs.getInt("alur"));
                hp.setPenokohan(rs.getInt("penokohan"));
                hp.setAkting(rs.getInt("akting"));
                hp.setRating(rs.getInt("rating"));
                dp.add(hp);
            }
        } catch(SQLException ex){
            Logger.getLogger(datamovieDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return dp;
    }

    @Override
    public void deleteAll(datamovie p) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(deleteAll);
            statement.executeUpdate();
                   
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            } catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }
}
