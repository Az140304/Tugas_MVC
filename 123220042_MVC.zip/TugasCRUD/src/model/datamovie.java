/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author DELL
 */
public class datamovie {
    private String judul;
    private int alur;
    private int penokohan;
    private int akting;
    private int rating;

    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul) {
        this.judul = judul;
    }

    public int getAlur() {
        return alur;
    }

    public void setAlur(int alur) {
        this.alur = alur;
    }

    public int getPenokohan() {
        return penokohan;
    }

    public void setPenokohan(int penokohan) {
        this.penokohan = penokohan;
    }

    public int getAkting() {
        return akting;
    }

    public void setAkting(int akting) {
        this.akting = akting;
    }
    
    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
    

    
    
}
