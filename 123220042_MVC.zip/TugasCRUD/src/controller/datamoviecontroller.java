/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.util.List;
import DAOdatamovie.datamovieDAO;
import model.*;
import view.MainView;
import DAOImplement.datamovieimplement;
/**
 *
 * @author DELL
 */

public class datamoviecontroller {
    MainView frame;
    datamovieimplement impldatamovie;
    List<datamovie> dp;
    int nilaiAlur, nilaiPenokohan, nilaiAkting, nilaiRating;
            
    public datamoviecontroller(MainView frame){
        this.frame = frame;
        impldatamovie = new datamovieDAO();
        dp = impldatamovie.getAll();
    }
    
    public void isitabel(){
        dp = impldatamovie.getAll();
        modeltabeldatamovie mp = new modeltabeldatamovie(dp);
        frame.getTabelDataMovie().setModel(mp);
    }
    
    public void insert(){
        datamovie dp = new datamovie();
        nilaiAlur =  Integer.parseInt((frame.getJTxtAlur().getText()));
        nilaiPenokohan =  Integer.parseInt(frame.getJTxtPenokohan().getText());
        nilaiAkting =  Integer.parseInt(frame.getJTxtAkting().getText());
        
        nilaiRating = (nilaiAlur + nilaiPenokohan + nilaiAkting)/ 3;
        
        dp.setJudul(frame.getJTxtJudul().getText());
        dp.setAlur(nilaiAlur);
        dp.setPenokohan(nilaiPenokohan);
        dp.setAkting(nilaiAkting);
        dp.setRating(nilaiRating);
        impldatamovie.insert(dp);
    }
    
    public void update(){
        datamovie dp = new datamovie();
        
        nilaiAlur =  Integer.parseInt((frame.getJTxtAlur().getText()));
        nilaiPenokohan =  Integer.parseInt(frame.getJTxtPenokohan().getText());
        nilaiAkting =  Integer.parseInt(frame.getJTxtAkting().getText());
        
        nilaiRating = (nilaiAlur + nilaiPenokohan + nilaiAkting)/ 3;
        
        dp.setJudul(frame.getJTxtJudul().getText());
        dp.setAlur(nilaiAlur);
        dp.setPenokohan(nilaiPenokohan);
        dp.setAkting(nilaiAkting);
        dp.setRating(nilaiRating);
        impldatamovie.update(dp);
    }
    
    public void delete(){
        String judul = frame.getJTxtJudul().getText();
        impldatamovie.delete(judul);
    }
    
    public void deleteAll(){
        datamovie dp = new datamovie();
        impldatamovie.deleteAll(dp);
    }
}
